CREATE DATABASE poo;

USE poo;

CREATE TABLE acompanhante (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(100),
    relacionamento VARCHAR(50)
);

CREATE TABLE paciente (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(100),
    idade INT,
    acompanhante_id INT,
    FOREIGN KEY (acompanhante_id) REFERENCES acompanhante(id)
);

CREATE TABLE medico (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(100),
    especialidade VARCHAR(100),
    paciente_id INT,
    FOREIGN KEY (paciente_id) REFERENCES paciente(id)
);

CREATE TABLE clinica (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(100),
    endereco VARCHAR(200),
    medico_id INT,
    FOREIGN KEY (medico_id) REFERENCES medico(id)
);
