import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

/**
 * Interface que define operações básicas de CRUD (Create, Read, Update, Delete).
 * Será implementada pelas classes de "View".
 */
public interface CRUDMedico {
    void cadastrar(Scanner scanner, MedicoModel medico); // Método para cadastrar um registro.
    void editar(Scanner scanner, MedicoModel medico);    // Método para editar um registro.
    void listar(ResultSet rs) throws SQLException;  // Método para listar registros.
    void remover(Scanner scanner, MedicoModel medico);   // Método para remover um registro.
}
