import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

public class MedicoController {
    private MedicoView view = new MedicoView();
    private MedicoModel model = new MedicoModel();

    // Método para cadastrar um médico
    public void cadastrarMedico(Scanner scanner) {
        view.cadastrar(scanner, model);

        String sql = "INSERT INTO medico (nome, crm, especialidade, telefone) VALUES (?, ?, ?, ?)";

        try (Connection connection = Conector.getConnection();
             PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setString(1, model.getNome());
            stmt.setString(2, model.getCrm());
            stmt.setString(3, model.getEspecialidade());
            stmt.setString(4, model.getTelefone());
            stmt.executeUpdate();
            System.out.println("Médico cadastrado com sucesso!");
        } catch (SQLException e) {
            System.out.println("Erro ao cadastrar médico: " + e.getMessage());
        }
    }

    // Método para listar todos os médicos
    public void listarMedicos() {
        String sql = "SELECT * FROM medico";

        try (Connection conn = Conector.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {
            view.listar(rs);
        } catch (SQLException e) {
            System.out.println("Erro ao listar médicos: " + e.getMessage());
        }
    }

    // Método para editar os dados de um médico
    public void editarMedico(Scanner scanner) {
        view.editar(scanner, model);

        String sql = "UPDATE medico SET nome = ?, crm = ?, especialidade = ?, telefone = ? WHERE id = ?";

        try (Connection connection = Conector.getConnection();
             PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setString(1, model.getNome());
            stmt.setString(2, model.getCrm());
            stmt.setString(3, model.getEspecialidade());
            stmt.setString(4, model.getTelefone());
            stmt.setInt(5, model.getId());
            int rowsAffected = stmt.executeUpdate();
            if (rowsAffected > 0) {
                System.out.println("Médico atualizado com sucesso!");
            } else {
                System.out.println("Médico não encontrado.");
            }
        } catch (SQLException e) {
            System.out.println("Erro ao editar médico: " + e.getMessage());
        }
    }

    // Método para remover um médico
    public void removerMedico(Scanner scanner) {
        view.remover(scanner, model);

        String sql = "DELETE FROM medico WHERE id = ?";

        try (Connection connection = Conector.getConnection();
             PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setInt(1, model.getId());
            int rowsAffected = stmt.executeUpdate();
            if (rowsAffected > 0) {
                System.out.println("Médico removido com sucesso!");
            } else {
                System.out.println("Médico não encontrado.");
            }
        } catch (SQLException e) {
            System.out.println("Erro ao remover médico: " + e.getMessage());
        }
    }
}
