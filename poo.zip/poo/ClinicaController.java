import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

public class ClinicaController {
    private ClinicaView view = new ClinicaView(); // view da clínica
    private ClinicaModel model = new ClinicaModel();   // model da clínica

    public void cadastrarClinica(Scanner scanner) {
        view.cadastrar(scanner, model);

        String sql = "INSERT INTO clinica (nome, cnpj, endereco, horario_atendimento) VALUES (?, ?, ?, ?)";

        try (Connection connection = Conector.getConnection();
             PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setString(1, model.getNome());
            stmt.setString(2, model.getCnpj());
            stmt.setString(3, model.getTelefone());
            stmt.setString(4, model.getEndereco());
            stmt.setString(5, model.getHorarioAtendimento());
            stmt.executeUpdate();
            System.out.println("Clínica cadastrada com sucesso!");
        } catch (SQLException e) {
            System.out.println("Erro ao cadastrar clínica: " + e.getMessage());
        }
    }

    public void listarClinicas() {
        String sql = "SELECT * FROM clinica";

        try (Connection connection = Conector.getConnection();
             PreparedStatement stmt = connection.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {
            view.listar(rs);
        } catch (SQLException e) {
            System.out.println("Erro ao listar clínicas: " + e.getMessage());
        }
    }

    public void editarClinica(Scanner scanner) {
        view.editar(scanner, model);

        String sql = "UPDATE clinica SET nome = ?, cnpj = ?, endereco = ?, horario_atendimento = ? WHERE id = ?";

        try (Connection connection = Conector.getConnection();
             PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setString(1, model.getNome());
            stmt.setString(2, model.getCnpj());
            stmt.setString(3, model.getTelefone());
            stmt.setString(4, model.getEndereco());
            stmt.setString(5, model.getHorarioAtendimento());
            stmt.setInt(6, model.getId());
            int rowsAffected = stmt.executeUpdate();
            if (rowsAffected > 0) {
                System.out.println("Clínica atualizada com sucesso!");
            } else {
                System.out.println("Clínica não encontrada.");
            }
        } catch (SQLException e) {
            System.out.println("Erro ao editar clínica: " + e.getMessage());
        }
    }

    public void removerClinica(Scanner scanner) {
        view.remover(scanner, model);

        String sql = "DELETE FROM clinica WHERE id = ?";

        try (Connection connection = Conector.getConnection();
             PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setInt(1, model.getId());
            int rowsAffected = stmt.executeUpdate();
            if (rowsAffected > 0) {
                System.out.println("Clínica removida com sucesso!");
            } else {
                System.out.println("Clínica não encontrada.");
            }
        } catch (SQLException e) {
            System.out.println("Erro ao remover clínica: " + e.getMessage());
        }
    }
}