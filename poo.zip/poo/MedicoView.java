import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

/**
 * Classe responsável pela interação com o usuário para a entidade Médico.
 * Implementa as operações de CRUD.
 */
public class MedicoView implements CRUDMedico {
    
    @Override
    public void cadastrar(Scanner scanner, MedicoModel medico) {

        System.out.print("Nome: ");
        medico.setNome(scanner.nextLine());
        System.out.print("CRM: ");
        medico.setCrm(scanner.nextLine());
        System.out.print("Especialidade: ");
        medico.setEspecialidade(scanner.nextLine());
        System.out.print("Telefone: ");
        medico.setTelefone(scanner.nextLine());
    }

    @Override
    public void editar(Scanner scanner, MedicoModel medico) {

        System.out.print("ID do médico a ser editado: ");
        medico.setId(scanner.nextInt());
        scanner.nextLine(); // Consumir a quebra de linha.
        System.out.print("Novo Nome: ");
        medico.setNome(scanner.nextLine());
        System.out.print("Novo CRM: ");
        medico.setCrm(scanner.nextLine());
        System.out.print("Nova Especialidade: ");
        medico.setEspecialidade(scanner.nextLine());
        System.out.print("Novo Telefone: ");
        medico.setTelefone(scanner.nextLine());
    }

    @Override
    public void listar(ResultSet rs) throws SQLException {
        System.out.println("\n--- Lista de Médicos ---");
        while (rs.next()) {
            System.out.println("ID: " + rs.getInt("id"));
            System.out.println("Nome: " + rs.getString("nome"));
            System.out.println("CRM: " + rs.getString("crm"));
            System.out.println("Especialidade: " + rs.getString("especialidade"));
            System.out.println("Telefone: " + rs.getString("telefone"));
            System.out.println("--------------------------");
        }
    }

    @Override
    public void remover(Scanner scanner, MedicoModel medico) {

        System.out.print("ID do médico a ser removido: ");
        medico.setId(scanner.nextInt());
    }
}
