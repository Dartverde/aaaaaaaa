import java.util.Scanner;

public class Principal {
    public static void main(String[] args) {
        // Instanciação dos controladores para gerenciar cada entidade do sistema.
        try ( // Scanner é usado para ler a entrada do usuário no terminal.
                Scanner scanner = new Scanner(System.in)) {
            // Instanciação dos controladores para gerenciar cada entidade do sistema.
            PacienteController pacienteController = new PacienteController(); // Controla as operações de CRUD de Pacientes.
            MedicoController medicoController = new MedicoController();       // Controla as operações de CRUD de Médicos.
            AcompanhanteController acompanhanteController = new AcompanhanteController(); // Controla as operações de CRUD de Acompanhantes.
            ClinicaController clinicaController = new ClinicaController();    // Controla as operações de CRUD de Clínicas.
            int opcao; // Variável para armazenar a escolha do usuário no menu.
            // Loop principal do sistema. Permanece ativo até que o usuário escolha a opção de saída.
            do {
                // Exibe o menu principal no terminal.
                System.out.println("\n--- Sistema de Gerenciamento ---");
                System.out.println("1. Gerenciar Pacientes");
                System.out.println("2. Gerenciar Medicos");
                System.out.println("3. Gerenciar Acompanhantes");
                System.out.println("4. Gerenciar Clinicas");
                System.out.println("5. Sair");
                System.out.print("Escolha uma opcao: ");
                
                // Lê a opção escolhida pelo usuário.
                opcao = scanner.nextInt();
                scanner.nextLine(); // Consome a quebra de linha pendente no buffer do Scanner.
                
                // Executa ações com base na opção selecionada pelo usuário.
                switch (opcao) {
                    case 1 -> // Invoca o método para cadastrar um novo paciente.
                        pacienteController.cadastrar(scanner);
                    case 2 -> // Invoca o método para cadastrar um novo médico.
                        medicoController.cadastrarMedico(scanner);
                    case 3 -> // Invoca o método para cadastrar um novo acompanhante.
                        acompanhanteController.cadastrarAcompanhante(scanner);
                    case 4 -> // Invoca o método para cadastrar uma nova clínica.
                        clinicaController.cadastrarClinica(scanner);
                    case 5 -> // Mensagem exibida quando o usuário escolhe sair do sistema.
                        System.out.println("Saindo...");
                    default -> // Mensagem exibida para opções inválidas (diferentes de 1 a 5).
                        System.out.println("Opção inválida!");
                }
            } while (opcao != 5); // O loop continua enquanto o usuário não escolher a opção 5 (Sair).
            // Fecha o Scanner para liberar os recursos.
        } // Controla as operações de CRUD de Pacientes.
    }
}
