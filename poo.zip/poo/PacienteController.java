import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;
/**
 * Controlador para gerenciar as operações de CRUD da entidade Paciente.
 */
public class PacienteController {
    private PacienteView view = new PacienteView();  // Interação com o usuário.
    private PacienteModel model = new PacienteModel(); // Modelo contendo os dados.

    /**
     * Cadastra um novo paciente no banco de dados.
     */
    public void cadastrar(Scanner scanner) {
        view.cadastrar(scanner, model); // Solicita os dados ao usuário.

        String sql = "INSERT INTO paciente (nome, cpf, idade, sexo, altura, peso, telefone, endereco, escolaridade) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";

        try (Connection conn = Conector.getConnection(); 
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, model.getNome());
            stmt.setString(2, model.getCpf());
            stmt.setInt(3, model.getIdade());
            stmt.setString(4, model.getSexo());
            stmt.setDouble(5, model.getAltura());
            stmt.setDouble(6, model.getPeso());
            stmt.setString(7, model.getTelefone());
            stmt.setString(8, model.getEndereco());
            stmt.setString(9, model.getEscolaridade());
            stmt.executeUpdate(); // Insere o registro no banco.
        } catch (SQLException e) {
            System.out.println("Erro ao cadastrar paciente: " + e.getMessage());
        }
    }

    /**
     * Lista todos os pacientes cadastrados no banco.
     */
    public void listar() {
        String sql = "SELECT * FROM paciente";

        try (Connection conn = Conector.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            view.listar(rs); // Exibe os resultados ao usuário.
        } catch (SQLException e) {
            System.out.println("Erro ao listar pacientes: " + e.getMessage());
        }
    }

    /**
     * Atualiza os dados de um paciente no banco.
     */
    public void editar(Scanner scanner) {
        view.editar(scanner, model); // Solicita os dados atualizados ao usuário.

        String sql = "UPDATE paciente SET nome = ?, cpf = ?, idade = ?, sexo = ?, altura = ?, peso = ?, " +
                     "telefone = ?, endereco = ?, escolaridade = ? WHERE id = ?";

        try (Connection conn = Conector.getConnection(); 
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, model.getNome());
            stmt.setString(2, model.getCpf());
            stmt.setInt(3, model.getIdade());
            stmt.setString(4, model.getSexo());
            stmt.setDouble(5, model.getAltura());
            stmt.setDouble(6, model.getPeso());
            stmt.setString(7, model.getTelefone());
            stmt.setString(8, model.getEndereco());
            stmt.setString(9, model.getEscolaridade());
            stmt.setInt(10, model.getId());
            int rowsAffected = stmt.executeUpdate();
            if (rowsAffected > 0) {
                System.out.println("Paciente atualizado com sucesso!");
            } else {
                System.out.println("Paciente não encontrado.");
            }
        } catch (SQLException e) {
            System.out.println("Erro ao editar paciente: " + e.getMessage());
        }
    }

    /**
     * Remove um paciente do banco de dados.
     */
    public void remover(Scanner scanner) {
        view.remover(scanner, model); // Solicita o ID do paciente a ser removido.

        String sql = "DELETE FROM paciente WHERE id = ?";

        try (Connection conn = Conector.getConnection(); 
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, model.getId());
            int rowsAffected = stmt.executeUpdate();
            if (rowsAffected > 0) {
                System.out.println("Paciente removido com sucesso!");
            } else {
                System.out.println("Paciente não encontrado.");
            }
        } catch (SQLException e) {
            System.out.println("Erro ao remover paciente: " + e.getMessage());
        }
    }
}
