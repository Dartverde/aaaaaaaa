import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;


public class AcompanhanteController {
    private AcompanhanteView view = new AcompanhanteView();
    private AcompanhanteModel model = new AcompanhanteModel();

    public void cadastrarAcompanhante(Scanner scanner) {
        view.cadastrar(scanner, model);

        String sql = "INSERT INTO acompanhante (nome, cpf, telefone, paciente_id) VALUES (?, ?, ?, ?)";

        try (Connection connection = Conector.getConnection();
             PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setString(1, model.getNome());
            stmt.setString(2, model.getCpf());
            stmt.setString(3, model.getTelefone());
            stmt.setInt(4, model.getPacienteId());
            stmt.executeUpdate();
            System.out.println("Acompanhante cadastrado com sucesso!");
        } catch (SQLException e) {
            System.out.println("Erro ao cadastrar acompanhante: " + e.getMessage());
        }
    }

    public void listarAcompanhantes() {
        String sql = "SELECT * FROM acompanhante";

        try (Connection connection = Conector.getConnection();
             PreparedStatement stmt = connection.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {
            view.listar(rs);
        } catch (SQLException e) {
            System.out.println("Erro ao listar acompanhantes: " + e.getMessage());
        }
    }

    public void editarAcompanhante(Scanner scanner) {
        view.editar(scanner, model);

        String sql = "UPDATE acompanhante SET nome = ?, cpf = ?, telefone = ?, paciente_id = ? WHERE id = ?";

        try (Connection connection = Conector.getConnection();
             PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setString(1, model.getNome());
            stmt.setString(2, model.getCpf());
            stmt.setString(3, model.getTelefone());
            stmt.setInt(4, model.getPacienteId());
            stmt.setInt(5, model.getId());
            int rowsAffected = stmt.executeUpdate();
            if (rowsAffected > 0) {
                System.out.println("Acompanhante atualizado com sucesso!");
            } else {
                System.out.println("Acompanhante não encontrado.");
            }
        } catch (SQLException e) {
            System.out.println("Erro ao editar acompanhante: " + e.getMessage());
        }
    }

    public void removerAcompanhante(Scanner scanner) {
        view.remover(scanner, model);

        String sql = "DELETE FROM acompanhante WHERE id = ?";

        try (Connection connection = Conector.getConnection();
             PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setInt(1, model.getId());
            int rowsAffected = stmt.executeUpdate();
            if (rowsAffected > 0) {
                System.out.println("Acompanhante removido com sucesso!");
            } else {
                System.out.println("Acompanhante não encontrado.");
            }
        } catch (SQLException e) {
            System.out.println("Erro ao remover acompanhante: " + e.getMessage());
        }
    }
}
