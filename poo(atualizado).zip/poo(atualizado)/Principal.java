import java.util.Scanner;

public class Principal {
    public static void main(String[] args) {
        // Instanciação dos controladores para gerenciar cada entidade do sistema.
        try ( // Scanner é usado para ler a entrada do usuário no terminal.
                Scanner scanner = new Scanner(System.in)) {
            // Instanciação dos controladores para gerenciar cada entidade do sistema.
            PacienteController pacienteController = new PacienteController(); // Controla as operações de CRUD de Pacientes.
            MedicoController medicoController = new MedicoController();       // Controla as operações de CRUD de Médicos.
            AcompanhanteController acompanhanteController = new AcompanhanteController(); // Controla as operações de CRUD de Acompanhantes.
            ClinicaController clinicaController = new ClinicaController();    // Controla as operações de CRUD de Clínicas.
            int opcao; // Variável para armazenar a escolha do usuário no menu.
            // Loop principal do sistema. Permanece ativo até que o usuário escolha a opção de saída.
            do {
                // Exibe o menu principal no terminal.
                System.out.println("\n--- Sistema de Gerenciamento ---");
                System.out.println("1. Cadastar Pacientes");
                System.out.println("2. Listar Pacientes");
                System.out.println("3. Editar Pacientes");
                System.out.println("4. Remover Pacientes");
                System.out.println("5. Cadastar Medicos");
                System.out.println("6. Listar Medicos");
                System.out.println("7. Editar Medicos");
                System.out.println("8. Remover Medicos");
                System.out.println("9. Cadastar Acompanhante");
                System.out.println("10. Listar Acompanhante");
                System.out.println("11. Editar Acompanhante");
                System.out.println("12. Remover Acompanhante");
                System.out.println("13. Cadastar Clinicas");
                System.out.println("14. Listar Clinicas");
                System.out.println("15. Editar Clinicas");
                System.out.println("16. Remover Clinicas");
                System.out.println("17. Sair");
                System.out.print("Escolha uma opcao: ");
                
                // Lê a opção escolhida pelo usuário.
                opcao = scanner.nextInt();
                scanner.nextLine(); // Consome a quebra de linha pendente no buffer do Scanner.
                
                // Executa ações com base na opção selecionada pelo usuário.
                switch (opcao) {
                    case 1 -> // Invoca o método para cadastrar um novo paciente.
                        pacienteController.cadastrar(scanner);
                    case 2 -> // Invoca o método para listar um novo paciente.
                        pacienteController.listar();
                    case 3 -> // Invoca o método para editar um novo paciente.
                        pacienteController.editar(scanner);
                    case 4 -> // Invoca o método para remover um novo paciente.
                        pacienteController.remover(scanner);
                    case 5 -> // Invoca o método para cadastrar um novo médico.
                        medicoController.cadastrarMedico(scanner);
                    case 6 -> // Invoca o método para listar um novo médico.
                        medicoController.listarMedicos();
                    case 7 -> // Invoca o método para editar um novo médico.
                        medicoController.editarMedico(scanner);
                    case 8 -> // Invoca o método para remover um novo médico.
                        medicoController.removerMedico(scanner);
                    case 9 -> // Invoca o método para cadastrar um novo acompanhante.
                        acompanhanteController.cadastrarAcompanhante(scanner);
                    case 10 -> // Invoca o método para listar um novo acompanhante.
                        acompanhanteController.listarAcompanhantes();
                    case 11 -> // Invoca o método para editar um novo acompanhante.
                        acompanhanteController.editarAcompanhante(scanner);
                    case 12 -> // Invoca o método para remover um novo acompanhante.
                        acompanhanteController.removerAcompanhante(scanner);
                    case 13 -> // Invoca o método para cadastrar uma nova clínica.
                        clinicaController.cadastrarClinica(scanner);
                    case 14 -> // Invoca o método para listar uma nova clínica.
                        clinicaController.listarClinicas();
                    case 15 -> // Invoca o método para editar uma nova clínica.
                        clinicaController.editarClinica(scanner);
                    case 16 -> // Invoca o método para remover uma nova clínica.
                        clinicaController.removerClinica(scanner);
                    case 17 -> // Mensagem exibida quando o usuário escolhe sair do sistema.
                        System.out.println("Saindo...");
                    default -> // Mensagem exibida para opções inválidas (diferentes de 1 a 5).
                        System.out.println("Opção inválida!");
                }
            } while (opcao != 5); // O loop continua enquanto o usuário não escolher a opção 5 (Sair).
            // Fecha o Scanner para liberar os recursos.
        } // Controla as operações de CRUD de Pacientes.
    }
}
