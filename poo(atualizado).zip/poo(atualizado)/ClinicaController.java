import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

/**
 * Controlador para gerenciar as operações da entidade Clinica.
 */
public class ClinicaController {
    private ClinicaView view = new ClinicaView(); // View da clínica
    private ClinicaModel model = new ClinicaModel();   // Model da clínica

    // Método para cadastrar uma nova clínica
    public void cadastrarClinica(Scanner scanner) {
        // Solicita os dados da clínica ao usuário por meio da View e os armazena no Model
        view.cadastrar(scanner, model);

        String sql = "INSERT INTO clinica (nome, cnpj, endereco, telefone, horario_atendimento) VALUES (?, ?, ?, ?, ?)";

        try (Connection connection = Conector.getConnection();
             PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setString(1, model.getNome());
            stmt.setString(2, model.getCnpj());
            stmt.setString(3, model.getTelefone());
            stmt.setString(4, model.getEndereco());
            stmt.setString(5, model.getHorarioAtendimento());
            stmt.executeUpdate();
            System.out.println("Clínica cadastrada com sucesso!");
        } catch (SQLException e) {
            // Captura e exibe qualquer erro que ocorra durante a execução do comando SQL
            System.out.println("Erro ao cadastrar clínica: " + e.getMessage());
        }
    }

    // Método para listar todas as clínicas
    public void listarClinicas() {
        String sql = "SELECT * FROM clinica";

        try (Connection connection = Conector.getConnection();
             PreparedStatement stmt = connection.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {
            view.listar(rs);
        } catch (SQLException e) {
            // Captura e exibe erros durante a execução do comando SQL
            System.out.println("Erro ao listar clínicas: " + e.getMessage());
        }
    }

    // Método para editar os dados de uma clínica
    public void editarClinica(Scanner scanner) {
        view.editar(scanner, model);

        String sql = "UPDATE clinica SET nome = ?, cnpj = ?, endereco = ?, telefone = ? horario_atendimento = ? WHERE id = ?";

        try (Connection connection = Conector.getConnection();
             PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setString(1, model.getNome());
            stmt.setString(2, model.getCnpj());
            stmt.setString(3, model.getTelefone());
            stmt.setString(4, model.getEndereco());
            stmt.setString(5, model.getHorarioAtendimento());
            stmt.setInt(6, model.getId());
            int rowsAffected = stmt.executeUpdate();
            if (rowsAffected > 0) {
                System.out.println("Clínica atualizada com sucesso!");
            } else {
                System.out.println("Clínica não encontrada.");
            }
        } catch (SQLException e) {
            // Captura e exibe qualquer erro que ocorra durante a execução do comando SQL
            System.out.println("Erro ao editar clínica: " + e.getMessage());
        }
    }

    // Método para remover uma clínica
    public void removerClinica(Scanner scanner) {
        view.remover(scanner, model);

        String sql = "DELETE FROM clinica WHERE id = ?";

        try (Connection connection = Conector.getConnection();
             PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setInt(1, model.getId());
            int rowsAffected = stmt.executeUpdate();
            if (rowsAffected > 0) {
                System.out.println("Clínica removida com sucesso!");
            } else {
                System.out.println("Clínica não encontrada.");
            }
        } catch (SQLException e) {
            // Captura e exibe qualquer erro que ocorra durante a execução do comando SQL
            System.out.println("Erro ao remover clínica: " + e.getMessage());
        }
    }
}