import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

/**
 * Interface para operações de CRUD para Acompanhantes. (Create, Read, Update, Delete).
 * Será implementada pelas classes de "View".
 */
public interface CRUDAcompanhante {
    void cadastrar(Scanner scanner, AcompanhanteModel acompanhante); // Cadastrar novo acompanhante
    void editar(Scanner scanner, AcompanhanteModel acompanhante);    // Editar acompanhante existente
    void listar(ResultSet rs) throws SQLException;                   // Listar acompanhantes
    void remover(Scanner scanner, AcompanhanteModel acompanhante);   // Remover acompanhante
}
