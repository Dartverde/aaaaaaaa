public class Id { // Vira Herança para View (Paciente, Clinica)
    private int id;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }
}
