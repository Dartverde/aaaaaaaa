import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

/**
 * View para gerenciar operações de CRUD relacionadas a Clínicas.
 * Implementa as operações de CRUDClinica.
 */
public class ClinicaView implements CRUDClinica {

    /**
     * Método para cadastrar uma nova clínica.
     * Recebe os dados da clínica através do Scanner e os armazena no modelo fornecido.
     */
    @Override
    public void cadastrar(Scanner scanner, ClinicaModel clinica) {
        System.out.print("Digite o nome da clínica: ");
        clinica.setNome(scanner.nextLine()); // Recebe o nome da clínica.

        System.out.print("Digite o endereço da clínica: ");
        clinica.setEndereco(scanner.nextLine()); // Recebe o endereço.

        System.out.print("Digite o telefone da clínica: ");
        clinica.setTelefone(scanner.nextLine()); // Recebe o telefone.

        System.out.print("Digite o CNPJ da clínica: ");
        clinica.setTelefone(scanner.nextLine()); // Recebe o CNPJ.

        System.out.print("Digite o Horario de Atendimento da clínica: ");
        clinica.setTelefone(scanner.nextLine()); // Recebe o Horario de Atendimento.
    }

    /**
     * Método para editar uma clínica existente.
     * Solicita o ID do registro e permite alterar seus dados.
     */
    @Override
    public void editar(Scanner scanner, ClinicaModel clinica) {
        System.out.print("Digite o ID da clínica que deseja editar: ");
        clinica.setId(scanner.nextInt()); // Recebe o ID da clínica.
        scanner.nextLine(); // Limpa a quebra de linha do Scanner.

        System.out.print("Digite o novo nome da clínica: ");
        clinica.setNome(scanner.nextLine()); // Atualiza o nome.

        System.out.print("Digite o novo endereço da clínica: ");
        clinica.setEndereco(scanner.nextLine()); // Atualiza o endereço.

        System.out.print("Digite o novo telefone da clínica: ");
        clinica.setTelefone(scanner.nextLine()); // Atualiza o telefone.

        System.out.print("Digite o novo CNPJ da clínica: ");
        clinica.setTelefone(scanner.nextLine()); // Atualiza o CNPJ.

        System.out.print("Digite o novo Horario de Atendimento da clínica: ");
        clinica.setTelefone(scanner.nextLine()); // Atualiza o Horario de Atendimento.
    }

    /**
     * Método para listar todas as clínicas.
     * Recebe um ResultSet com os dados vindos do banco e os exibe no console.
     */
    @Override
    public void listar(ResultSet rs) throws SQLException {
        System.out.println("\n--- Lista de Clínicas ---");
        while (rs.next()) { // Itera pelos registros no ResultSet.
            System.out.println("ID: " + rs.getInt("id")); // Exibe o ID.
            System.out.println("Nome: " + rs.getString("nome")); // Exibe o nome.
            System.out.println("Endereço: " + rs.getString("endereco")); // Exibe o endereço.
            System.out.println("Telefone: " + rs.getString("telefone")); // Exibe o telefone.
            System.out.println("CNPJ: " + rs.getString("CNPJ")); // Exibe o CNPJ.
            System.out.println("Horario de Atendimento: " + rs.getString("Horario de Atendimento")); // Exibe o Horario de Atendimento.
            System.out.println("--------------------------");
        }
    }

    /**
     * Método para remover uma clínica pelo ID.
     * Solicita o ID da clínica que será excluída e atualiza o modelo.
     */
    @Override
    public void remover(Scanner scanner, ClinicaModel clinica) {
        System.out.print("Digite o ID da clínica que deseja remover: ");
        clinica.setId(scanner.nextInt()); // Recebe o ID da clínica a ser removida.
    }
}