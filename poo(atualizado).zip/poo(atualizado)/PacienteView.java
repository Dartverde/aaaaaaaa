import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

/**
 * Classe responsável pela interação com o usuário para a entidade Paciente.
 * Implementa as operações de CRUDPaciente.
 */
public class PacienteView implements CRUDPaciente {
    
    @Override
    public void cadastrar(Scanner scanner, PacienteModel paciente) {
        System.out.print("Nome: ");
        paciente.setNome(scanner.nextLine());
        System.out.print("CPF: ");
        paciente.setCpf(scanner.nextLine());
        System.out.print("Idade: ");
        paciente.setIdade(scanner.nextInt());
        scanner.nextLine(); // Consumir a quebra de linha.
        System.out.print("Sexo: ");
        paciente.setSexo(scanner.nextLine());
        System.out.print("Altura: ");
        paciente.setAltura(scanner.nextDouble());
        System.out.print("Peso: ");
        paciente.setPeso(scanner.nextDouble());
        scanner.nextLine(); // Consumir a quebra de linha.
        System.out.print("Telefone: ");
        paciente.setTelefone(scanner.nextLine());
        System.out.print("Endereço: ");
        paciente.setEndereco(scanner.nextLine());
        System.out.print("Escolaridade: ");
        paciente.setEscolaridade(scanner.nextLine());
    }

    @Override
    public void editar(Scanner scanner, PacienteModel paciente) {

        System.out.print("ID do paciente a ser editado: ");
        paciente.setId(scanner.nextInt());
        scanner.nextLine(); // Consumir a quebra de linha.
        System.out.print("Novo Nome: ");
        paciente.setNome(scanner.nextLine());
        System.out.print("Novo CPF: ");
        paciente.setCpf(scanner.nextLine());
        System.out.print("Nova Idade: ");
        paciente.setIdade(scanner.nextInt());
        scanner.nextLine(); // Consumir a quebra de linha.
        System.out.print("Novo Sexo: ");
        paciente.setSexo(scanner.nextLine());
        System.out.print("Nova Altura: ");
        paciente.setAltura(scanner.nextDouble());
        System.out.print("Novo Peso: ");
        paciente.setPeso(scanner.nextDouble());
        scanner.nextLine(); // Consumir a quebra de linha.
        System.out.print("Novo Telefone: ");
        paciente.setTelefone(scanner.nextLine());
        System.out.print("Novo Endereço: ");
        paciente.setEndereco(scanner.nextLine());
        System.out.print("Nova Escolaridade: ");
        paciente.setEscolaridade(scanner.nextLine());
    }

    @Override
    public void listar(ResultSet rs) throws SQLException {
        System.out.println("\n--- Lista de Pacientes ---");
        while (rs.next()) {
            System.out.println("ID: " + rs.getInt("id"));
            System.out.println("Nome: " + rs.getString("nome"));
            System.out.println("CPF: " + rs.getString("cpf"));
            System.out.println("Idade: " + rs.getInt("idade"));
            System.out.println("Sexo: " + rs.getString("sexo"));
            System.out.println("Altura: " + rs.getDouble("altura"));
            System.out.println("Peso: " + rs.getDouble("peso"));
            System.out.println("Telefone: " + rs.getString("telefone"));
            System.out.println("Endereço: " + rs.getString("endereco"));
            System.out.println("Escolaridade: " + rs.getString("escolaridade"));
            System.out.println("--------------------------");
        }
    }

    @Override
    public void remover(Scanner scanner, PacienteModel paciente) {

        System.out.print("ID do paciente a ser removido: ");
        paciente.setId(scanner.nextInt());
    }
}
