import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class Conector {
    private static final String URL = "jdbc:mysql://localhost:3306/poo"; // Nome do seu banco de dados
    private static final String USER = "root"; // Usuário do banco de dados
    private static final String PASSWORD = ""; // Senha do banco de dados

    // Método para obter conexão com o banco
    public static Connection getConnection() throws SQLException {
        return DriverManager.getConnection(URL, USER, PASSWORD);
    }
}
