import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

/**
 * Classe responsável pela interação com o usuário para a entidade Acompanhante.
 * Implementa as operações de CRUDAcompanhante.
 */
public class AcompanhanteView implements CRUDAcompanhante {

    @Override
    public void cadastrar(Scanner scanner, AcompanhanteModel acompanhante) {
        System.out.print("Nome: ");
        acompanhante.setNome(scanner.nextLine());
        System.out.print("Endereço: ");
        acompanhante.setEndereco(scanner.nextLine());
        System.out.print("Telefone: ");
        acompanhante.setTelefone(scanner.nextLine());
        System.out.print("CPF: ");
        acompanhante.setCpf(scanner.nextLine());
    }

    @Override
    public void editar(Scanner scanner, AcompanhanteModel acompanhante) {
        System.out.print("ID do acompanhante a ser editado: ");
        acompanhante.setId(scanner.nextInt());
        scanner.nextLine();
        System.out.print("Novo Nome: ");
        acompanhante.setNome(scanner.nextLine());
        System.out.print("Novo Endereço: ");
        acompanhante.setEndereco(scanner.nextLine());
        System.out.print("Novo Telefone: ");
        acompanhante.setTelefone(scanner.nextLine());
        System.out.print("Novo CPF: ");
        acompanhante.setCpf(scanner.nextLine());
    }

    @Override
    public void listar(ResultSet rs) throws SQLException {
        System.out.println("\n--- Lista de Acompanhantes ---");
        while (rs.next()) {
            System.out.println("ID: " + rs.getInt("id"));
            System.out.println("Nome: " + rs.getString("nome"));
            System.out.println("Endereço: " + rs.getString("endereco"));
            System.out.println("Telefone: " + rs.getString("telefone"));
            System.out.println("CPF: " + rs.getString("CPF"));
            System.out.println("--------------------------");
        }
    }

    @Override
    public void remover(Scanner scanner, AcompanhanteModel acompanhante) {
        System.out.print("ID do acompanhante a ser removido: ");
        acompanhante.setId(scanner.nextInt());
    }
}
