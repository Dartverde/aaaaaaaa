/**
 * Classe modelo que representa um médico no sistema.
 */
public class MedicoModel extends Id  {
    private String nome;      // Nome do médico.
    private String crm;       // CRM do médico.
    private String especialidade; // Especialidade do médico.
    private String telefone;  // Telefone do médico.
    private String email;     // Email do médico.


    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getCrm() {
        return crm;
    }

    public void setCrm(String crm) {
        this.crm = crm;
    }

    public String getEspecialidade() {
        return especialidade;
    }

    public void setEspecialidade(String especialidade) {
        this.especialidade = especialidade;
    }

    public String getTelefone() {
        return telefone;
    }

    public void setTelefone(String telefone) {
        this.telefone = telefone;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }


}
